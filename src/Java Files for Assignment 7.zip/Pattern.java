public abstract class Pattern {
    //dummy methods
    public abstract int getSizeX();
    public abstract int getSizeY();
    public abstract boolean getCell(int x, int y);
}
